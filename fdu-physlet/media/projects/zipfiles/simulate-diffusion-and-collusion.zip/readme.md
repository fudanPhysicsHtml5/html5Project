# simulate the phenomenon of article collision and diffusion

use bootstrap to reconstruct the program  

use normal distribution as the initial speed distribution