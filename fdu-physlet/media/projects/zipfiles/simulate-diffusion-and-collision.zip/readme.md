# simulate the phenomenon of article collision and diffusion
- click collusion.html to run
- the project is based on bootstrap and CanvasJs