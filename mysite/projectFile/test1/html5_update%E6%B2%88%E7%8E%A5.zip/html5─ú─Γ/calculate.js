var N=799;
var h=39.95/N;
var T=400;
var V=new Array(N+2);
var A=new Array(N+2),B=new Array(N+2),C=new Array(N+2),Ui=new Array(N+2),Uf=new Array(N+2);
var canvas = document.getElementById("myCanvas"),
    context = canvas.getContext("2d");
var button= document.getElementById("controller"),
    scalecontroller=document.getElementById("scalecontrol"),
    paused = true;
var dragging=false,scale=false,change12=false;
var number=0,number1=0,number2=0;
var deltacontainer=document.getElementById("deltacontrol"),
    wellcontainer=document.getElementById("wellcontrol"),
    deltatrue=document.getElementById("deltatruetime"),
    welltrue=document.getElementById("welltruetime");
var reset=document.getElementById("reset");
var k0range=document.getElementById("k0Range");
var k0rec=[],k0counter=0;
var phaserange=document.getElementById("phaseRange");
var phaserec=[];
var k0truetime=document.getElementById("k0truetime"),
    phasetruetime=document.getElementById("phasetruetime");
var waveadd=document.getElementById("wavecontroller");
var wavecontainer=document.getElementById("wavecontrol");
var guassian=false,sigma;
var sigmarange=document.getElementById("sigmaRange"),
    guassiank0range=document.getElementById("guassiank0Range"),
    guassiank0true=document.getElementById("guassiank0truetime"),
    sigmatrue=document.getElementById("sigmatruetime");
var guassianadd=document.getElementById("guassiancontroller");
var pcanvas=document.getElementById("portion"),
    pcontext = pcanvas.getContext("2d");
var max=0,min=N;
var portionbefore1=0,portionmiddle1=0,portionafter1=0;
var portionbefore2=0,portionmiddle2=0,portionafter2=0;
var portiontotal=0;
var timecounter=0;
var scan=document.getElementById("scancontroller");
var scancanvas = document.getElementById("scangraph"),
    scancontext = scancanvas.getContext("2d");
var timecounter=0;

function complex(real,imaginary){
    if (isNaN(real)||isNaN(imaginary)){
        throw new TypeError();
    }
    this.r=real;
    this.i=imaginary;
}
function complexAdd(c1,c2) {
    return new complex(c1.r+c2.r,c1.i+c2.i);
}
function complexMinus(c1,c2) {
    return new complex(c1.r-c2.r,c1.i-c2.i);
}
function complexMultiply(c1,c2){
    return new complex(c1.r*c2.r-c1.i*c2.i,c1.r*c2.i+c1.i*c2.r);
}
function complexDivide(c1,c2){
    return new complex(1.0*(c1.r*c2.r+c1.i*c2.i)/(c2.i*c2.i+c2.r*c2.r),1.0*(-c1.r*c2.i+c1.i*c2.r)/(c2.i*c2.i+c2.r*c2.r))
}
function complexOut(c){
    if(c.i<0){
        document.write(c.r+"-"+Math.abs(c.i)+"i");
    }
    else if (c.i==0){
        document.write(c.r);
    }
    else{
        document.write(c.r+"+"+c.i+"i");
    }
}

function setting(){
    var i;
    context.save();

    context.beginPath();
    context.rect(0,canvas.height/2+10,canvas.width, 10);
    context.fillStyle = "rgba(0,150,255,0.3)";
    context.fill();
    context.font="15px Cambria";
    for (i=0;i<=9;i++){
        if (i*50==canvas.height/2){
            continue;
        }
        context.beginPath();
        context.setLineDash([2, 5]);
        context.moveTo(0,i*50);
        context.lineTo(canvas.width,i*50);
        context.lineWidth = 1;
        context.strokeStyle = "black";
        context.stroke();

        context.fillText(canvas.height/2-i*50,5,i*50);
        context.fillStyle="Black";
        context.fill();
    }

    for (i=0;i<=15;i++){
        context.fillText(i*50,5+i*canvas.width/16,canvas.height/2+20);
        context.fillStyle="Black";
        context.fill();
        context.beginPath();
        context.setLineDash([1, 5]);
        context.moveTo(i*canvas.width/16,0);
        context.lineTo(i*canvas.width/16,canvas.height);
        context.lineWidth = 1;
        context.strokeStyle = "black";
        context.stroke();


    }
    context.restore();

    pcontext.save();
    pcontext.beginPath();
    pcontext.moveTo(20,0);
    pcontext.lineTo(20,pcanvas.height);
    pcontext.lineWidth = 1;
    pcontext.strokeStyle = "black";
    pcontext.stroke();

    pcontext.beginPath();
    pcontext.moveTo(0,180);
    pcontext.lineTo(pcanvas.width,180);
    pcontext.lineWidth = 1;
    pcontext.strokeStyle = "black";
    pcontext.stroke();

    pcontext.font="10px Cambria";
    for (i=0;i<11;i=i+2){
        pcontext.fillText(i/10,5,-i/10*160+190);
    }
    pcontext.fillText("时间",pcanvas.width-20,190);
    pcontext.font="15px Cambria";
    pcontext.fillText("黑：势前",pcanvas.width-80,20);
    pcontext.fillStyle="blue";
    pcontext.fillText("蓝：势中",pcanvas.width-80,40);
    pcontext.fillStyle="red";
    pcontext.fillText("红：势后",pcanvas.width-80,60);
    pcontext.restore();

    scancontext.save();
    scancontext.beginPath();
    scancontext.moveTo(20,0);
    scancontext.lineTo(20,pcanvas.height);
    scancontext.lineWidth = 1;
    scancontext.strokeStyle = "black";
    scancontext.stroke();

    scancontext.beginPath();
    scancontext.moveTo(0,180);
    scancontext.lineTo(pcanvas.width,180);
    scancontext.lineWidth = 1;
    scancontext.strokeStyle = "black";
    scancontext.stroke();
    scancontext.font="10px Cambria";
    for (i=0;i<11;i=i+2){
        scancontext.fillText(i/10,5,-i/10*160+190);
    }
    for (i=1;i<11;i++){
        scancontext.fillText(i*i,i*i*5+20,190);
    }
    pcontext.fillText("能量（k^2）",pcanvas.width-20,190);
    pcontext.font="15px Cambria"
    scancontext.restore();

}
function Vinitialization() {
    for (var i=0;i<N+2;i++){
        V[i]=0.0;
    }

}
function initialization(){
    Ui[0]=new complex(0.0,0.0);Ui[N+1]=new complex(0.0,0.0);
    for (var i=1;i<=N;i++){
        Ui[i]=new complex(0.0,0.0);
        if(!guassian){
            for (var j=0;j<k0counter;j++){
                Ui[i]=complexAdd(Ui[i],new complex(Math.cos((i*h/40+0.5)*k0rec[j]*Math.PI+phaserec[j])/Math.sqrt(N+1)/k0counter,Math.sin((i*h/40+0.5)*k0rec[j]*Math.PI+phaserec[j])/Math.sqrt(N+1)/k0counter));

            }
        }
        else {
            Ui[i]=new complex(1.0/Math.sqrt(2*3.14159*sigma*sigma)*Math.exp(-Math.pow((i*h-10)/sigma,2))*Math.cos((i*h-10)*guassiank0),
               1.0/Math.sqrt(2*3.14159*sigma*sigma)*Math.exp(-Math.pow((i*h-10)/sigma,2))*Math.sin((i*h-10)*guassiank0));
        }
    }
    Uf[0]=new complex(0.0,0.0);Uf[N+1]=new complex(0.0,0.0);
    for(var i=0;i<=N+1;i++){
        A[i]=new complex(0.0,0.0);
        B[i]=new complex(0.0,0.0);
        C[i]=new complex(0.0,0.0);
    }
}
function scaninitialization(scank,scansigma){
    Ui[0]=new complex(0.0,0.0);Ui[N+1]=new complex(0.0,0.0);
    for (var i=1;i<=N;i++){
        Ui[i]=new complex(0.0,0.0);
        Ui[i]=new complex(1.0/Math.sqrt(2*3.14159*scansigma*scansigma)*Math.exp(-Math.pow((i*h-10)/scansigma,2))*Math.cos((i*h-10)*scank),
            1.0/Math.sqrt(2*3.14159*scansigma*scansigma)*Math.exp(-Math.pow((i*h-10)/scansigma,2))*Math.sin((i*h-10)*scank));
    }
    Uf[0]=new complex(0.0,0.0);Uf[N+1]=new complex(0.0,0.0);
    for(var i=0;i<=N+1;i++){
        A[i]=new complex(0.0,0.0);
        B[i]=new complex(0.0,0.0);
        C[i]=new complex(0.0,0.0);
    }
}
function updateV(loc){
    V[number]=canvas.height/2-loc.y;
    drawInitial();
    deltatrue.innerHTML="位置"+number+"大小"+V[number];
}

function scaleupdateV(loc) {
    var i;
    if (number1<=number2){
        for(i=number1;i<=number2;i++){
            V[i]=canvas.height/2-loc.y;
        }
        welltrue.innerHTML="位置"+number1+"-"+number2+"大小"+V[number1];
    }
    else{
        for(i=number2;i<=number1;i++){
            V[i]=canvas.height/2-loc.y;
        }
        welltrue.innerHTML="位置"+number2+"-"+number1+"大小"+V[number1];
    }
    drawInitial();
}

function update(){
    var i;
    var A1,A2,A3,A4;
    var B1,C1;
    for(var i=1;i<=N;i++){
        A1=complexMinus(new complex(0.0,0.0),Ui[i-1]);
        A2=complexMinus(A1,Ui[i+1]);
        A3=complexMultiply(Ui[i],new complex(2.0*(V[i]*h*h+1),0));
        A4 =complexMultiply(Ui[i],new complex(0,4.0*T*h*h));
        A[i]=complexAdd(complexAdd(A3,A2),A4);

    }
    for (i=1;i<N+2;i++){
        if(i==1){
            B[i]=new complex(2.0+2.0*V[i]*h*h,-4.0*T*h*h);
            C[i]=new complex(A[i].r,A[i].i);
        }
        else {
            B1=complexDivide(new complex(1.0,0.0),B[i-1]);
            B[i]=complexMinus(new complex(2.0+2.0*V[i]*h*h,-4.0*T*h*h),B1);
            C1=complexDivide(C[i-1],B[i-1]);
            C[i]=complexAdd(C1,A[i]);
        }
    }
}

function clearCanvas() {
    canvas.height=canvas.height;
}

function drawInitial() {
    var i;
    clearCanvas();
    context.save();

    context.beginPath();
    for (i=0;i<=N;i++){
        //complexOut(Ui[i]);
        if(!guassian){
            context.moveTo(i*0.05*30, canvas.height/2-(Ui[i].r*Ui[i].r+Ui[i].i*Ui[i].i)*N*50);
            context.lineTo((i+1)*0.05*30,canvas.height/2-(Ui[i+1].r*Ui[i+1].r+Ui[i+1].i*Ui[i+1].i)*N*50);
            //context.moveTo(i*0.05*30, canvas.height/2-(Ui[i].r)*N/8);
            //context.lineTo((i+1)*0.05*30, canvas.height/2-(Ui[i+1].r)*N/8);
        }
        else{
            context.moveTo(i*0.05*30, canvas.height/2-(Ui[i].r*Ui[i].r+Ui[i].i*Ui[i].i)*50);
            context.lineTo((i+1)*0.05*30,canvas.height/2-(Ui[i+1].r*Ui[i+1].r+Ui[i+1].i*Ui[i+1].i)*50);
        }

    }
    context.lineWidth = 1;
    context.strokeStyle = "black";
    context.stroke();

    context.beginPath();
    for (i=0;i<=N;i++){
        //complexOut(Ui[i]);
        context.moveTo(i*0.05*30, canvas.height/2-V[i]);
        context.lineTo((i+1)*0.05*30,canvas.height/2-V[i+1]);
    }
    context.lineWidth = 0.5;
    context.strokeStyle="Red";
    context.stroke();

    context.restore();
    setting();
}

function drawportion(time) {
    portiontotal=0;
    portionbefore1=0;portionbefore2=0;
    portionmiddle1=0;portionmiddle2=0;
    portionafter1=0;portionafter2=0;
    for (var i=0;i<=N+1;i++){
        portiontotal=portiontotal+Ui[i].r*Ui[i].r+Ui[i].i*Ui[i].i;
    }
    for (var i=0;i<=min;i++){
        portionbefore1=portionbefore1+Ui[i].r*Ui[i].r+Ui[i].i*Ui[i].i;
        portionbefore2=portionbefore2+Uf[i].r*Uf[i].r+Uf[i].i*Uf[i].i;
    }
    for (var i=min;i<=max;i++){
        portionmiddle1=portionmiddle1+Ui[i].r*Ui[i].r+Ui[i].i*Ui[i].i;
        portionmiddle2=portionmiddle2+Uf[i].r*Uf[i].r+Uf[i].i*Uf[i].i;
    }
    for (var i=max;i<=N;i++){
        portionafter1=portionafter1+Ui[i].r*Ui[i].r+Ui[i].i*Ui[i].i;
        portionafter2=portionafter2+Uf[i].r*Uf[i].r+Uf[i].i*Uf[i].i;
    }
    //alert(time+" "+portionbefore1+" "+portionbefore2);

    pcontext.save();
    pcontext.beginPath();
    pcontext.moveTo(time*0.1+20,-portionbefore1/portiontotal*160+180);
    pcontext.lineTo((time+1)*0.1+20,-portionbefore2/portiontotal*160+180);
    pcontext.lineWidth = 2;
    pcontext.strokeStyle = "black";
    pcontext.stroke();

    pcontext.beginPath();
    pcontext.moveTo(time*0.1+20,-portionmiddle1/portiontotal*160+180);
    pcontext.lineTo((time+1)*0.1+20,-portionmiddle2/portiontotal*160+180);
    pcontext.lineWidth = 2;
    pcontext.strokeStyle = "blue";
    pcontext.stroke();

    pcontext.beginPath();
    pcontext.moveTo(time*0.1+20,-portionafter1/portiontotal*160+180);
    pcontext.lineTo((time+1)*0.1+20,-portionafter2/portiontotal*160+180);
    pcontext.lineWidth = 2;
    pcontext.strokeStyle = "red";
    pcontext.stroke();
    pcontext.restore();
    timecounter++;
}
function draw(currentTime){
    var k;
    requestAnimationFrame(draw);
    if (!paused) {
        //alert(min+" "+max);
        update();
        for (k=N;k>0;k--){
            if(k==N){
                Uf[k]=complexDivide(complexMinus(new complex(0.0,0.0),C[k]), B[k]);
            }
            else {
                Uf[k]=complexDivide(complexMinus(Uf[k+1],C[k]), B[k]);
            }
        }
        drawportion(timecounter);
        for (k=0;k<N+2;k++){
            Ui[k].r=Uf[k].r;
            Ui[k].i=Uf[k].i;
        }

    }
    drawInitial();
}
function scandraw(){
    var k;
    for(timecounter=0;timecounter<=100;timecounter++){
        update();
        for (k=N;k>0;k--){
            if(k==N){
                Uf[k]=complexDivide(complexMinus(new complex(0.0,0.0),C[k]), B[k]);
            }
            else {
                Uf[k]=complexDivide(complexMinus(Uf[k+1],C[k]), B[k]);
            }
        }
        for (k=0;k<N+2;k++){
            Ui[k].r=Uf[k].r;
            Ui[k].i=Uf[k].i;
        }
    }
}

button.onclick = function(e) {
    if (paused) {
        paused = false;
        button.value = "停止";
    }
    else {
        paused = true;
        button.value = "开始";
    }
}

scalecontroller.onclick = function(e) {
    if (!scale) {
        scale= true;
        scalecontroller.value = "选择中";
    }
    else {
        scale = false;
        scalecontroller.value = "批量";
    }
}

reset.onclick=function (e) {
    if (paused){
        k0counter=0;
        k0rec=[];
        phaserec=[];
        guassian=false;
        max=0;min=N;
        timecounter=0;
        Vinitialization();
        initialization();
        setting();
        drawInitial();
        deltacontainer.innerHTML="";
        wellcontainer.innerHTML="";
        wavecontainer.innerHTML="";
        sigmatrue.innerHTML="";
        guassiank0true.innerHTML="";
        pcanvas.height=pcanvas.height;
        scancanvas.height=scancanvas.height
    }
}

waveadd.onclick=function (e) {
    if (paused){
        k0rec.push(k0range.value);
        phaserec.push(2*Math.PI*phaserange.value/20);
        k0counter++;

        var node=document.createElement("LI");
        var textnode=document.createTextNode("速度"+k0range.value+"相位2Pi*"+phaserange.value/20);
        node.appendChild(textnode);
        wavecontainer.appendChild(node);
        initialization();
        drawInitial();
    }
}
guassianadd.onclick=function (e) {
    if(paused){
        sigma=sigmarange.value/10;
        guassiank0=guassiank0range.value;
        guassian=true;
        initialization();
        drawInitial();
    }
}
scan.onclick=function(e){
    var k;
    if(paused){
        if(max==0&&min==N){
            alert("未初始化");
        }
        else {
            for (k=1;k<=10;k++){
                scaninitialization(k,0.5);
                scandraw();
                portiontotal=0;
                portionbefore1=0;
                portionafter1=0;
                for (var i=0;i<=N+1;i++){
                    portiontotal=portiontotal+Ui[i].r*Ui[i].r+Ui[i].i*Ui[i].i;
                }
                for (var i=0;i<=min;i++){
                    portionbefore1=portionbefore1+Ui[i].r*Ui[i].r+Ui[i].i*Ui[i].i;
                }
                for (var i=max;i<=N;i++){
                    portionafter1=portionafter1+Ui[i].r*Ui[i].r+Ui[i].i*Ui[i].i;
                }

                scancontext.save();
                scancontext.beginPath();
                scancontext.arc(k*k*5+20, -portionbefore1/portiontotal*160+180, 3, 0, Math.PI*2, true);
                scancontext.fillStyle = "black";
                scancontext.fill();
                scancontext.beginPath();
                scancontext.arc(k*k*5+20, -portionafter1/portiontotal*160+180, 3, 0, Math.PI*2, true);
                scancontext.fillStyle = "red";
                scancontext.fill();

            }
        }
    }
}
guassiank0range.onchange=function (e) {
    guassiank0true.innerHTML="k0="+guassiank0range.value;
}
sigmarange.onchange=function (e) {
    sigmatrue.innerHTML="sigma="+sigmarange.value/10;
}
k0range.onchange=function(e){
    k0truetime.innerHTML="k0="+k0range.value;
}
phaserange.onchange=function(e){
    phasetruetime.innerHTML="phase=2Pi*"+phaserange.value/10;
}

function windowToCanvas(x, y) {
    var bbox = canvas.getBoundingClientRect();
    return { x: x - bbox.left * (canvas.width/bbox.width),
        y: y - bbox.top * (canvas.height/bbox.height)  };
}

function isPointInStroke(loc) {
    var i;
    context.beginPath();
    for (i=0;i<=N;i++){
        context.moveTo(i*0.05*30, canvas.height/2-V[i]);
        context.lineTo((i+1)*0.05*30,canvas.height/2-V[i+1]);
    }

    return context.isPointInStroke(loc.x, loc.y);
}

canvas.onmousemove = function(e) {
    var loc = windowToCanvas(e.clientX, e.clientY);
    if (dragging) {
        canvas.style.cursor = "pointer";
        if(!scale){
            updateV(loc);
        }
        else{
            scalecontroller.value="拖曳中";
            scaleupdateV(loc);
        }
    }
    else{

        if (isPointInStroke(loc) && paused) {
            canvas.style.cursor = "pointer";
        }
        else {
            canvas.style.cursor = "auto";
        }
    }


}

canvas.onmousedown = function(e) {
    var loc = windowToCanvas(e.clientX, e.clientY);
    if(!scale){
        if (isPointInStroke(loc) && paused) {
            dragging = true;
            number=Math.round(loc.x/canvas.width*N);
        }
    }
    else{
        if (isPointInStroke(loc)&&paused){
            if (!change12){
                dragging=false;
                number1=Math.round(loc.x/canvas.width*N);
            }
            else{
                dragging=true;
                number2=Math.round(loc.x/canvas.width*N);
                change12=false;
            }
        }

    }
}

canvas.onmouseup = function(e) {
    if (dragging) {
        dragging = false;
    }
    if (scale&&number1!=0){
        if (number2==0){
            change12=true;
        }
        else if (number1!=number2) {
            if (number1<number2){
                if (number1<min){
                    min=number1;
                }
                if (number2>max){
                    max=number2;
                }
                var node=document.createElement("LI");
                var textnode=document.createTextNode("位置"+number1+"至"+number2+"大小"+V[number1].toFixed(2));
            }
            else{
                if (number2<min){
                    min=number2;
                }
                if (number1>max){
                    max=number1;
                }
                var node=document.createElement("LI");
                var textnode=document.createTextNode("位置"+number2+"至"+number1+"大小"+V[number1].toFixed(2));
            }
            node.appendChild(textnode);
            wellcontainer.appendChild(node);
            number1=0;
            number2=0;
            scale=false;
            scalecontroller.value="批量";
        }
    }
    else if (number!=0){
        if (number>max) {
            max=number;
        }
        if (number<min) {
            min=number;
        }
        var node=document.createElement("LI");
        var textnode=document.createTextNode("位置"+number+"大小"+V[number].toFixed(2));
        node.appendChild(textnode);
        deltacontainer.appendChild(node);
        number=0;
    }
}


//alert(k0);
setting();
Vinitialization();
initialization();
drawInitial();
draw();
